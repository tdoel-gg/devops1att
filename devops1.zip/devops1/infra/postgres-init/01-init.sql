CREATE TABLE IF NOT EXISTS products (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL UNIQUE,
  price DOUBLE PRECISION NOT NULL,
  image_url TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS orders (
  id BIGSERIAL PRIMARY KEY,
  user_login VARCHAR(255) NOT NULL,
  product_id BIGINT NOT NULL,
  quantity INTEGER NOT NULL,
  status VARCHAR(32) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE products ADD COLUMN IF NOT EXISTS image_url TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ;
UPDATE products SET image_url = '/media/shop-images/products/laptop.svg' WHERE name = 'Ceramic Mug' AND (image_url IS NULL OR image_url = '');
UPDATE products SET image_url = '/media/shop-images/products/headphones.svg' WHERE name = 'Scented Candle' AND (image_url IS NULL OR image_url = '');
UPDATE products SET image_url = '/media/shop-images/products/mouse.svg' WHERE name = 'Potted Plant' AND (image_url IS NULL OR image_url = '');

INSERT INTO products (name, price, image_url) VALUES
('Ceramic Mug', 24.99, '/media/shop-images/products/laptop.svg'),
('Scented Candle', 18.99, '/media/shop-images/products/headphones.svg'),
('Potted Plant', 32.99, '/media/shop-images/products/mouse.svg')
ON CONFLICT (name) DO NOTHING;

DELETE FROM products WHERE name = 'Admin Test Product';
DELETE FROM products WHERE name = 'Laptop';
DELETE FROM products WHERE name = 'Headphones';
DELETE FROM products WHERE name = 'Mouse';
