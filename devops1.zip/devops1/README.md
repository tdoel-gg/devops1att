# Лабораторная работа: Microshop Platform

## Исходное задание

Вы команда платформенной разработки, которой передали прототип интернет-магазина. Бизнес хочет запустить MVP быстро, но с заделом на масштабирование. Поэтому архитектура уже микросервисная: разные языки, отдельные сервисы, очередь, кэш, объектное хранилище и API-gateway.

Ваша задача как DevOps-инженеров: собрать это в воспроизводимый контейнерный стенд, где весь магазин поднимается одной командой и работает как единая система.

## Отчёт

### Введение

Цель проекта — собрать готовый микросервисный стенд интернет-магазина в Docker Compose. Система должна подниматься командой `docker compose up --build`, при этом все прикладные сервисы, инфраструктурные компоненты и gateway должны работать как единое целое.

Проект включает:
- frontend на React;
- auth-сервис на Go;
- backend на Java/Spring Boot;
- асинхронный worker на Python;
- инфраструктуру: PostgreSQL, Redis, RabbitMQ, etcd, MinIO;
- единую точку входа `nginx-gateway`.

Отчёт описывает архитектуру, ход работы, реализацию, проверку и выводы по результатам.

### Архитектура проекта

Схема архитектуры:
- `frontend-react` отвечает за пользовательский интерфейс,
- `auth-service-go` реализует регистрацию и авторизацию,
- `backend-java` предоставляет API, бизнес-логику и админ-функции,
- `order-worker-python` обрабатывает заказы из очереди,
- `nginx-gateway` объединяет все трафик на одном порту.

Инфраструктурные сервисы:
- `postgres` — транзакционная СУБД для товаров и заказов,
- `redis` — хранение сессий и кэша,
- `rabbitmq` — очередь заказов,
- `etcd` — ключевое хранилище пользователей auth-сервиса,
- `minio` — объектное хранилище изображений.

Маршрутизация в `nginx-gateway`:
- `/api/auth/` -> `auth-service:8081`
- `/api/` -> `backend-service:8080`
- `/media/` -> `minio:9000`
- `/` -> `frontend:80`

Эта конфигурация обеспечила единый вход в систему через `http://localhost:3000`.

### Ход работы: этапы и пояснения

1. Анализ первичной структуры репозитория.
   - Нашла все сервисы и инфраструктурные каталоги.
   - Проверила наличие `Dockerfile` для каждого прикладного модуля.
   - Нашла `compose.yml`, `.env.example` и `docs/runbook.md`.

2. Проверка Docker Compose.
   - Убедилась, что `compose.yml` содержит все сервисы и зависимости.
   - Прописала `depends_on`, healthchecks и сеть `microshop`.
   - Убедилась, что web- и api-сервисы работают в одной сети.

3. Проверка Nginx gateway.
   - Посмотрела `nginx-gateway/nginx.conf`.
   - Убедилась, что маршруты соответствуют требованиям.
   - Проверила, что Nginx использует DNS Docker-сети через `127.0.0.11`.

4. Проверка контейнеризации сервисов.
   - `auth-service-go` использует multi-stage build для Go-приложения.
   - `backend-java` использует Maven multi-stage build и итоговый образ JRE.
   - `order-worker-python` использует Python 3.12 slim и зависимости из `requirements.txt`.
   - `frontend-react` собирается в статические файлы с Vite, а потом разворачивается через Nginx.

5. Оценка конфигураций и env-переменных.
   - `.env.example` содержит нужные параметры для всех сервисов.
   - `auth-service-go` может менять настройки через `AUTH_PORT`, `ETCD_ENDPOINTS`, `REDIS_ADDR`, `SESSION_TTL_SECONDS`.
   - `backend-java` получает доступ к БД, Redis, RabbitMQ и MinIO через переменные `SPRING_...` и `SHOP_...`.
   - `order-worker-python` читает `config.yml`, но при запуске настройки заменяются переменными окружения.

6. Нужно было описать пользовательские сценарии.
   - регистрация, логин, витрина, добавление товара в корзину, оформление заказа,
   - личный кабинет и асинхронная обработка статуса заказа.

7. Проведение тестов и проверок.
   - `docker compose up --build` поднимает весь стек.
   - `http://localhost:3000` открывает frontend.
   - маршруты API `/api/products`, `/api/auth/login`, `/api/orders/my` прошли базовую проверку.

### Реализация компонентов

#### 1. `auth-service-go`

Цель: регистрация и авторизация пользователей.

Реализация:
- Язык: Go.
- Конфигурация: `auth-service-go/config.yml` + env-переменные.
- Хранилище пользователей: etcd.
- Хранилище сессий: Redis.

Docker:
- Multi-stage build: в первом этапе загружаются модули и собирается бинарник.
- Во втором этапе создаётся лёгкий `alpine`-образ.
- `CMD ["/app/auth-service"]` запускает сервис.

Параметры окружения:
- `AUTH_CONFIG` — путь к `config.yml`.
- `AUTH_PORT` — порт сервиса.
- `ETCD_ENDPOINTS` — адрес etcd.
- `REDIS_ADDR` — адрес Redis.
- `SESSION_TTL_SECONDS` — время жизни сессии.

Значение:
- auth-сервис обеспечивает разделение ответственности и выносит учет пользователей и сессий за пределы backend.
- Это упрощает масштабирование и делает систему более гибкой.

#### 2. `backend-java`

Цель: API магазина, бизнес-логика, админ-панель.

Реализация:
- Язык: Java 21, Spring Boot.
- Хранение данных: PostgreSQL.
- Кэш: Redis.
- Очередь: RabbitMQ.
- Хранение медиа: MinIO.

Docker:
- Multi-stage build: `maven` собирает артефакт, runtime образ на JRE.
- Образ содержит только `backend-java.jar`.

Проект использует конфигурацию через окружение:
- `SPRING_DATASOURCE_URL`, `SPRING_DATASOURCE_USERNAME`, `SPRING_DATASOURCE_PASSWORD`.
- `SPRING_DATA_REDIS_HOST`, `SPRING_DATA_REDIS_PORT`.
- `SPRING_RABBITMQ_HOST`, `SPRING_RABBITMQ_PORT`, `SPRING_RABBITMQ_USERNAME`, `SPRING_RABBITMQ_PASSWORD`.
- `SHOP_MINIO_ENDPOINT`, `SHOP_MINIO_ACCESS_KEY`, `SHOP_MINIO_SECRET_KEY`, `SHOP_MINIO_BUCKET`, `SHOP_MINIO_PUBLIC_BASE_PATH`.
- `SHOP_CORS_ALLOWED_ORIGIN` для доступа frontend.
- `SHOP_ORDERS_QUEUE` для имени очереди заказов.

Конфигурация RabbitMQ:
- `backend-java/src/main/java/com/shop/backend/config/RabbitConfig.java` объявляет очередь с именем `shop.queue.orders`.

Значение:
- backend управляет товарами, заказами, пользуется общей БД,
- публикует события заказов в очередь,
- возвращает клиенту актуальное состояние заказа.

#### 3. `order-worker-python`

Цель: асинхронная обработка заказов.

Реализация:
- Язык: Python 3.12.
- RabbitMQ consumer: пакет `pika`.
- PostgreSQL client: `psycopg2`.
- Конфигурация: `order-worker-python/config.yml` + env-переменные.

Логика:
- подключается к RabbitMQ,
- подписывается на очередь `orders.queue`,
- считывает сообщение с `orderId`,
- обновляет статус заказа в таблице `orders` на `Обработано`.

Особенности:
- использует `basic_qos(prefetch_count=10)` для управления нагрузкой;
- обрабатывает ошибки с повторной постановкой в очередь.

Docker:
- базовый образ `python:3.12-slim`.
- зависимости устанавливаются из `requirements.txt`.
- в контейнер копируется `worker.py` и конфиг.

#### 4. `frontend-react`

Цель: пользовательский интерфейс витрины, кабинета и админки.

Реализация:
- React 18, Vite, React Router.
- UI-библиотека: Bootstrap + MDB React UI Kit.

Docker:
- Сборка на Node (`node:20-alpine`).
- Итоговые статические файлы разворачиваются в Nginx.
- `public/config.json` копируется в сборку.

Особенности:
- фронтенд работает на порту 80 внутри контейнера;
- обращается к API по единой точке входа gateway;
- поддерживает страницы `Login`, `Register`, `Showcase`, `Cabinet`, `Admin`.

#### 5. `nginx-gateway`

Цель: единая точка входа для фронтенда, API и медиа.

Реализация:
- образ на `nginx:1.27-alpine`.
- один конфигурационный файл `nginx.conf`.
- проксирование запросов в сервисы внутри Docker-сети.

Параметры:
- проксирует `/api/auth/` к auth-сервису,
- `/api/` к backend,
- `/media/` к MinIO,
- `/` к frontend.

Это даёт пользователю единый URL и скрывает внутреннюю сетевую структуру.

### Инфраструктурная часть

#### Docker Compose

Файл `compose.yml` поднимает:
- `gateway`, `frontend`, `auth-service`, `backend-service`, `order-worker`,
- `postgres`, `redis`, `rabbitmq`, `etcd`, `minio`, `minio-init`.

Особенности:
- используется сеть `microshop` для всех контейнеров;
- у сервисов есть `depends_on` и healthchecks;
- данные сохраняются в named volumes:
  - `postgres-data`, `redis-data`, `rabbitmq-data`, `etcd-data`, `minio-data`.

`minio-init` запускается после поднятия MinIO и служит для инициализации bucket-а.

#### Сервис PostgreSQL

- образ: `postgres:16-alpine`.
- инициализация: `infra/postgres-init/01-init.sql`.
- среда: `POSTGRES_DB=shop`, `POSTGRES_USER=shop`, `POSTGRES_PASSWORD=shop`.
- healthcheck: `pg_isready`.

#### Сервис Redis

- образ: `redis:7-alpine`.
- запуск: `redis-server --appendonly yes`.
- healthcheck: `redis-cli ping`.

#### Сервис RabbitMQ

- образ: `rabbitmq:3.13-management-alpine`.
- exposes: management `15672`.
- healthcheck: `rabbitmq-diagnostics -q ping`.

#### Сервис etcd

- образ: `quay.io/coreos/etcd:v3.5.5`.
- настроен как single-node кластер.
- хранилище пользователей доступно по `etcd:2379`.

#### Сервис MinIO

- образ: `minio/minio:RELEASE.2025-02-28T09-55-16Z`.
- expose console `9001`.
- credentials: `minioadmin` / `minioadmin`.
- bucket: `shop-images`.

### Запуск и проверка работоспособности

#### Подготовка

1. Скопировать `.env.example` в `.env`.
2. Убедиться, что Docker Desktop запущен.
3. Запустить:
   `docker compose up --build`

#### Ожидаемые адреса

- `http://localhost:3000` — frontend и gateway.
- `http://localhost:9001` — MinIO Console.
- `http://localhost:15672` — RabbitMQ Management.

#### Базовые проверки

- `docker compose ps` — все контейнеры должны быть `Up`.
- `GET http://localhost:3000/api/products` — статус `200`.
- `GET http://localhost:3000/media/...` — доступ к медиа.
- регистрация и логин через frontend.
- создание заказа и проверка его статуса в кабинете.

#### Проверка очереди и worker-а

- backend публикует сообщение в очередь `orders.queue`.
- worker читает сообщение и обновляет заказ в PostgreSQL.
- при успехе статус заказа меняется на `Обработано`.

### Выводы

Работа над проектом показала, что такая микросервисная архитектура подходит для MVP, которое можно масштабировать.

- Отдельные сервисы делают систему проще для изменения.
- Docker Compose даёт повторяемую среду.
- Nginx gateway решает задачу единой точки входа.
- `etcd`, `Redis`, `RabbitMQ`, `PostgreSQL`, `MinIO` используются вместе и показывают реальный стек.

