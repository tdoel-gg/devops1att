import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { fetchProducts } from '../services/productService'
import { checkoutOrder } from '../services/orderService'

function formatPrice(price) {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 2
  }).format(price)
}

export function ShowcasePage({ cfg, cart, setCart, token }) {
  const [products, setProducts] = useState([])
  const [qtyMap, setQtyMap] = useState({})
  const [message, setMessage] = useState('')
  const navigate = useNavigate()

  useEffect(() => {
    fetchProducts(cfg.backendBaseUrl)
      .then(setProducts)
      .catch(() => setMessage('Не удалось загрузить витрину товаров'))
  }, [cfg.backendBaseUrl])

  function addToCart(product) {
    const qty = Number(qtyMap[product.id] || 1)
    if (qty < 1) return
    const key = String(product.id)
    const previous = cart[key]

    setCart({
      ...cart,
      [key]: {
        product,
        quantity: previous ? previous.quantity + qty : qty
      }
    })
    setMessage(`Добавлено в корзину: ${product.name}`)
  }

  function clearCart() {
    setCart({})
    setMessage('Корзина очищена')
  }

  async function checkout() {
    const items = Object.values(cart).map((item) => ({
      productId: item.product.id,
      quantity: item.quantity
    }))

    if (items.length === 0) {
      setMessage('Корзина пуста')
      return
    }
    if (!token) {
      navigate('/login')
      return
    }

    const response = await checkoutOrder(cfg.backendBaseUrl, token, items)
    if (!response.ok) {
      setMessage(`Ошибка оформления заказа: ${await response.text()}`)
      return
    }

    setCart({})
    setMessage('Заказ оформлен. Проверьте личный кабинет.')
    navigate('/cabinet')
  }

  return (
    <section className='page-stack'>
      <div className='simple-box'>
        <h1 className='page-title'>Витрина</h1>
      </div>

      <div className='catalog-layout'>
        <div className='catalog-grid'>
          {products.map((product) => (
            <article className='simple-card' key={product.id}>
              <div className='simple-card__image'>
                <img src={product.imageUrl} alt={product.name} />
              </div>
              <div className='simple-card__body'>
                <div className='simple-card__row'>
                  <div>
                    <h2>{product.name}</h2>
                  </div>
                  <strong>{formatPrice(product.price)}</strong>
                </div>

                <div className='simple-card__controls'>
                  <label className='field'>
                    <span>Количество</span>
                    <input
                      type='number'
                      min='1'
                      value={qtyMap[product.id] || 1}
                      onChange={(e) => setQtyMap({ ...qtyMap, [product.id]: e.target.value })}
                    />
                  </label>
                  <button type='button' className='simple-button' onClick={() => addToCart(product)}>
                    В корзину
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>

        <aside className='simple-box'>
          <div className='box-header'>
            <h2>Корзина</h2>
            <span>{Object.values(cart).length} поз.</span>
          </div>

          {Object.values(cart).length === 0 ? (
            <p className='page-text'>Корзина пуста.</p>
          ) : (
            <ul className='simple-list'>
              {Object.values(cart).map((item) => (
                <li key={item.product.id}>
                  <div>
                    <strong>{item.product.name}</strong>
                    <span>{formatPrice(item.product.price)}</span>
                  </div>
                  <b>x{item.quantity}</b>
                </li>
              ))}
            </ul>
          )}

          <div className='basket-actions'>
            <button type='button' className='simple-button simple-button--full' onClick={checkout}>
              Оформить заказ
            </button>
            <button type='button' className='simple-button simple-button--light simple-button--full' onClick={clearCart}>
              Очистить корзину
            </button>
          </div>

          {message && <p className='message-line'>{message}</p>}
        </aside>
      </div>
    </section>
  )
}
