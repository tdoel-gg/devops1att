import { useState } from 'react'
import { CardPage } from '../components/common/CardPage'
import { createProduct } from '../services/adminService'

export function AdminPage({ cfg, token }) {
  const [name, setName] = useState('')
  const [price, setPrice] = useState('')
  const [file, setFile] = useState(null)
  const [message, setMessage] = useState('')

  async function submit(event) {
    event.preventDefault()
    if (!token) {
      setMessage('Нужен вход под admin')
      return
    }

    const response = await createProduct(cfg.backendBaseUrl, token, { name, price, file })
    setMessage(response.ok ? 'Товар добавлен' : `Ошибка добавления товара: ${await response.text()}`)

    if (response.ok) {
      setName('')
      setPrice('')
      setFile(null)
    }
  }

  return (
    <CardPage
      title='Админка'
      description='Добавление нового товара в каталог магазина.'
    >
      <p className='page-text'>Для добавления товара войдите под пользователем <code>admin</code>.</p>
      <form onSubmit={submit} className='form-stack'>
        <label className='field'>
          <span>Название товара</span>
          <input value={name} onChange={(e) => setName(e.target.value)} required />
        </label>
        <label className='field'>
          <span>Цена</span>
          <input type='number' min='0.01' step='0.01' value={price} onChange={(e) => setPrice(e.target.value)} required />
        </label>
        <label className='field'>
          <span>Изображение</span>
          <input type='file' accept='image/*' onChange={(e) => setFile(e.target.files?.[0] || null)} required />
        </label>
        <button type='submit' className='simple-button simple-button--full'>Добавить товар</button>
        {message && <p className='message-line'>{message}</p>}
      </form>
    </CardPage>
  )
}
