import { useEffect, useState } from 'react'
import { CardPage } from '../components/common/CardPage'
import { fetchMyOrders } from '../services/orderService'

export function CabinetPage({ cfg, token }) {
  const [orders, setOrders] = useState([])
  const [message, setMessage] = useState('')

  useEffect(() => {
    if (!token) {
      setMessage('Выполните вход, чтобы видеть заказы')
      setOrders([])
      return
    }

    fetchMyOrders(cfg.backendBaseUrl, token)
      .then((data) => {
        setOrders(data)
        setMessage('')
      })
      .catch((err) => {
        setMessage(`Не удалось загрузить заказы: ${err.message}`)
      })
  }, [cfg.backendBaseUrl, token])

  return (
    <CardPage
      title='Личный кабинет'
      description='Здесь отображаются ваши заказы и их текущие статусы.'
    >
      {message && <p className='message-line'>{message}</p>}
      {orders.length > 0 && (
        <ul className='simple-list'>
          {orders.map((order) => (
            <li key={order.id}>
              <div>
                <span>Заказ #{order.id}</span>
                <h3>{order.productName}</h3>
              </div>
              <div>
                <span>{order.quantity} шт.</span>
                <strong>{order.status}</strong>
              </div>
            </li>
          ))}
        </ul>
      )}
    </CardPage>
  )
}
