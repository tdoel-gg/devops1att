# Microshop Runbook

## Требования
- Docker Desktop с включенным Docker Compose

## Быстрый старт
1. Скопируйте `.env.example` в `.env`:
   `Copy-Item .env.example .env`
2. Соберите и поднимите весь стенд:
   `docker compose up --build`
3. Откройте витрину:
   `http://localhost:3000`

## Полезные адреса
- Витрина и API gateway: `http://localhost:3000`
- MinIO Console: `http://localhost:9001`
- RabbitMQ Management: `http://localhost:15672`

## Базовые проверки
- `docker compose ps`
- `Invoke-WebRequest http://localhost:3000/api/products`
- `Invoke-WebRequest http://localhost:3000/media/shop-images/products/laptop.svg`

## Остановка
- `docker compose down`

## Остановка без потери данных
- `docker compose down`

## Полный сброс данных
- `docker compose down -v`
