from flask import Flask, request, render_template_string
from flask_sqlalchemy import SQLAlchemy
import os
import time

app = Flask(__name__)

DB_HOST = os.getenv('DB_HOST', 'postgres-svc')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_USER = os.getenv('DB_USER', 'postgres')
DB_PASSWORD = os.getenv('DB_PASSWORD', 'postgres123')
DB_NAME = os.getenv('DB_NAME', 'messages_db')

app.config['SQLALCHEMY_DATABASE_URI'] = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now())

@app.route('/')
def home():
    name = os.getenv('NAME', 'Lev')
    messages = Message.query.all()
    
    html = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Message App</title>
        <style>
            body {{ font-family: Arial; text-align: center; margin-top: 50px; }}
            .container {{ max-width: 600px; margin: 0 auto; }}
            input {{ padding: 10px; width: 70%; }}
            button {{ padding: 10px 20px; background: #4CAF50; color: white; border: none; }}
            .message {{ background: #f0f0f0; margin: 10px 0; padding: 10px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Привет, {name}!</h1>
            <form method="post" action="/add">
                <input type="text" name="text" placeholder="Введите сообщение..." required>
                <button type="submit">Отправить</button>
            </form>
            <h2>Сообщения ({len(messages)})</h2>
            {"".join(f'<div class="message">{m.text}</div>' for m in messages)}
        </div>
    </body>
    </html>
    '''
    return html

@app.route('/add', methods=['POST'])
def add():
    text = request.form.get('text')
    if text:
        msg = Message(text=text)
        db.session.add(msg)
        db.session.commit()
    return '<script>window.location.href="/";</script>'

if __name__ == '__main__':
    time.sleep(5)
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=8080)