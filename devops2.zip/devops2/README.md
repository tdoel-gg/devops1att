# Отчет по проекту: Microshop Platform

## Введение

### Описание проекта
Проект "Microshop Platform" представляет собой разработку микросервисной архитектуры для интернет-магазина. Целью является создание масштабируемой платформы, способной обрабатывать пользовательские сценарии, такие как регистрация, авторизация, просмотр товаров, управление корзиной, оформление заказов и административные функции. Проект реализован в рамках лабораторной работы по DevOps, где команда платформенной разработки получила прототип магазина и должна была подготовить его к быстрому запуску MVP с учетом будущей масштабируемости.

Архитектура проекта основана на микросервисном подходе, что позволяет разделить функциональность на независимые сервисы, написанные на разных языках программирования. Это обеспечивает гибкость, возможность независимого развертывания и масштабирования каждого компонента. Проект включает прикладные сервисы (auth-service, backend, order-worker, frontend) и инфраструктурные компоненты (базы данных, кэш, очередь сообщений, объектное хранилище).

### Цели проекта
Основные цели проекта:
- Докеризация каждого прикладного сервиса для обеспечения переносимости и изоляции.
- Создание единого контейнерного стенда с помощью Docker Compose, где весь магазин запускается одной командой.
- Настройка межсервисного взаимодействия через сеть, переменные окружения и API-шлюз.
- Реализация единой точки входа через Nginx Gateway для маршрутизации запросов.
- Обеспечение работоспособности ключевых пользовательских сценариев: регистрация, логин, витрина товаров, корзина, заказы, личный кабинет, асинхронная обработка заказов.
- Подготовка к развертыванию в Kubernetes для продакшн-среды.

Проект также включает задачу по развертыванию простого REST-приложения в Kubernetes, что демонстрирует навыки работы с оркестрацией контейнеров.

### Архитектура и технологии
Архитектура проекта включает следующие компоненты:

- **Прикладные сервисы:**
  - `auth-service-go`: Сервис аутентификации на Go, использующий etcd для хранения пользователей и Redis для сессий.
  - `backend-java`: Основной API на Java/Spring Boot, взаимодействующий с PostgreSQL, Redis, RabbitMQ и MinIO.
  - `order-worker-python`: Воркер на Python для обработки заказов из очереди RabbitMQ.
  - `frontend-react`: Веб-интерфейс на React для витрины, кабинета и админки.
  - `nginx-gateway`: Шлюз на Nginx для маршрутизации запросов.

- **Инфраструктурные сервисы:**
  - PostgreSQL: Основная база данных для товаров и заказов.
  - Redis: Кэш и хранение сессий.
  - RabbitMQ: Очередь для асинхронной обработки заказов.
  - etcd: Хранилище для пользователей auth-сервиса.
  - MinIO: S3-совместимое объектное хранилище для изображений товаров.

Технологии: Docker, Docker Compose, Kubernetes, Nginx, Python (Flask), Go, Java (Spring Boot), React, PostgreSQL, Redis, RabbitMQ, etcd, MinIO.

## Ход работы

### Подготовка рабочего окружения
Работа выполнялась на операционной системе Windows с использованием Docker Desktop для контейнеризации и встроенного Kubernetes. Были установлены следующие инструменты:
- Docker Desktop с Kubernetes.
- kubectl для управления кластером.
- Python, Go, Java для разработки сервисов.
- Node.js для frontend.
- Git для версионирования кода.

Проверка окружения включала:
- Проверку контекста Kubernetes: `kubectl config get-contexts`.
- Проверку кластера: `kubectl cluster-info`.

### Докеризация сервисов
Каждый прикладной сервис был докеризован с собственным Dockerfile:
- **auth-service-go**: Dockerfile на основе golang:alpine, копирование исходного кода, сборка и запуск.
- **backend-java**: Dockerfile с maven для сборки JAR, затем на основе openjdk для запуска.
- **order-worker-python**: Dockerfile с python:alpine, установка зависимостей из requirements.txt.
- **frontend-react**: Dockerfile с node для сборки, затем nginx для сервировки статических файлов.
- **nginx-gateway**: Dockerfile на основе nginx:alpine с копированием конфигурации nginx.conf.

Пример Dockerfile для auth-service-go:
```dockerfile
FROM golang:1.21-alpine AS builder
WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN go build -o auth-service ./cmd/auth-service

FROM alpine:latest
RUN apk --no-cache add ca-certificates
WORKDIR /root/
COPY --from=builder /app/auth-service .
COPY config.yml .
CMD ["./auth-service"]
```

### Настройка Docker Compose
Был создан docker-compose.yml для поднятия всего стека. Он включает все сервисы с их зависимостями, переменными окружения, сетью microshop и volumes для данных.

Ключевые моменты:
- Использование depends_on для порядка запуска.
- Переменные окружения для конфигурации подключений.
- Volumes для PostgreSQL и MinIO.
- Порт 3000 для nginx-gateway.

Пример фрагмента:
```yaml
services:
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: shop
      POSTGRES_USER: shop
      POSTGRES_PASSWORD: shop
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./infra/postgres-init:/docker-entrypoint-initdb.d:ro
    networks:
      - microshop
```

Запуск: `docker compose up --build`.

### Конфигурация Nginx Gateway
Nginx Gateway настроен как единая точка входа на порту 3000. Конфигурация в nginx-gateway/nginx.conf включает маршрутизацию:
- /api/auth/ -> auth-service:8081
- /api/ -> backend-service:8080
- /media/ -> minio:9000
- / -> frontend:80

Пример конфигурации:
```nginx
server {
  listen 80;
  resolver 127.0.0.11 ipv6=off valid=10s;

  location /api/auth/ {
    proxy_pass http://auth-service:8081/;
    proxy_set_header Host $host;
    ...
  }
  ...
}
```

### Развертывание в Kubernetes
Для демонстрации развертывания в Kubernetes была реализована отдельная задача: простое REST-приложение на Python/Flask, отдающее HTML-страницу с параметром из ConfigMap.

Шаги:
1. Создание приложения в k8s-app/main.py.
2. Dockerfile для сборки образа.
3. ConfigMap для передачи переменной NAME.
4. Deployment с Service и Ingress для публикации.
5. Загрузка образа в Docker Hub.
6. Применение манифестов: `kubectl apply -f configmap.yaml -f deployment-fixed.yaml`.
7. Проверка: `kubectl get pods`, доступ по Ingress.

Пример Deployment:
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: k8s-app
spec:
  replicas: 1
  selector:
    matchLabels:
      app: k8s-app
  template:
    metadata:
      labels:
        app: k8s-app
    spec:
      containers:
      - name: k8s-app
        image: your-dockerhub/k8s-app:latest
        ports:
        - containerPort: 8080
        env:
        - name: NAME
          valueFrom:
            configMapKeyRef:
              name: app-config
              key: name
```

### Тестирование и проверка работоспособности
Тестирование включало:
- Запуск стека: `docker compose up --build`.
- Проверка статусов: `docker compose ps`.
- Тестирование API через curl или браузер:
  - Регистрация: POST /api/auth/register
  - Логин: POST /api/auth/login
  - Получение товаров: GET /api/products
  - Оформление заказа: POST /api/orders/checkout
- Проверка frontend на http://localhost:3000.
- Инициализация MinIO с bucket и seed-данными.
- В Kubernetes: проверка подов, сервисов, Ingress.

### Проблемы и решения
Во время работы возникли следующие проблемы:
- Зависимости сервисов: решено через depends_on в compose.
- DNS-разрешение в Nginx: добавлен resolver 127.0.0.11.
- Переменные окружения: тщательно настроены для каждого сервиса.
- В Kubernetes: проблемы с Ingress в Docker Desktop - решено через port-forward или локальный доступ.

## Вывод

### Результаты проекта
Проект успешно реализован: создан контейнерный стенд для микросервисной платформы интернет-магазина, который запускается одной командой и обеспечивает все заявленные сценарии. Nginx Gateway корректно маршрутизирует запросы, сервисы взаимодействуют через сеть и переменные. Дополнительно продемонстрировано развертывание в Kubernetes.

### Достигнутые цели
- Все сервисы докеризованы и интегрированы в compose.
- Единая точка входа настроена.
- Пользовательские сценарии работают: регистрация, логин, витрина, заказы.
- Подготовлен задел для масштабирования и продакшн-развертывания.
