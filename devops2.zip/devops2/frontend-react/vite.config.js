cd C:\Users\lkeka\Downloads\devops-practice1-docker-compose-main\devops-practice1-docker-compose-mainimport { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()]
})
