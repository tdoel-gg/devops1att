Запуск окружения:

1. Соберите и запустите все сервисы:

```powershell
docker compose up --build
```

2. Проверьте статус:

```powershell
docker compose ps
```

3. Откройте http://localhost:3000 — будет доступен frontend через nginx-gateway.

Проверки API:

- GET http://localhost:3000/api/products — должен вернуть JSON список товаров.
- POST http://localhost:3000/api/auth/register — регистрация: {"login":"user","password":"pass"}
- POST http://localhost:3000/api/auth/login — логин: вернёт {"token":"..."}
- POST http://localhost:3000/api/orders/checkout — оформление заказа (X-Session-Token в заголовке).

Примечания:
- Инициализация MinIO происходит в контейнере `minio-init`, который создаёт bucket `shop-images` и копирует содержимое из `infra/minio-init/seed`.
- База данных PostgreSQL и MinIO используют Docker volumes `pgdata` и `minio-data` для сохранения данных между перезапусками.
