from flask import Flask
import os

app = Flask(__name__)

@app.route('/')
def hello():
    name = os.getenv('NAME', 'Guest')
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>K8S Hello App</title>
        <style>
            * {{
                box-sizing: border-box;
            }}
            body {{
                min-height: 100vh;
                margin: 0;
                font-family: "Segoe UI", Arial, sans-serif;
                color: #172033;
                background: #f6f8fb;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 32px;
            }}
            .page {{
                width: min(720px, 100%);
                border: 1px solid #d8e0ec;
                border-radius: 8px;
                background: #ffffff;
                box-shadow: 0 18px 45px rgba(23, 32, 51, 0.10);
                overflow: hidden;
            }}
            .header {{
                background: #16324f;
                color: #ffffff;
                padding: 28px 34px;
            }}
            .label {{
                margin: 0 0 10px;
                font-size: 13px;
                text-transform: uppercase;
                letter-spacing: 0.08em;
                color: #b9d4ef;
            }}
            h1 {{
                margin: 0;
                font-size: 40px;
                line-height: 1.15;
            }}
            .content {{
                padding: 30px 34px 34px;
            }}
            .env-row {{
                display: flex;
                justify-content: space-between;
                gap: 18px;
                padding: 16px 0;
                border-bottom: 1px solid #e7edf5;
            }}
            .env-row:first-child {{
                border-top: 1px solid #e7edf5;
            }}
            .key {{
                color: #64748b;
                font-weight: 600;
            }}
            .value {{
                color: #0f766e;
                font-weight: 700;
            }}
            .note {{
                margin: 24px 0 0;
                color: #475569;
                line-height: 1.6;
            }}
            footer {{
                margin-top: 26px;
                color: #7b8797;
                font-size: 13px;
            }}
        </style>
    </head>
    <body>
        <div class="page">
            <section class="header">
                <p class="label">Kubernetes demo application</p>
                <h1>Hello, {name}!</h1>
            </section>
            <main class="content">
                <div class="env-row">
                    <span class="key">Environment variable</span>
                    <span class="value">NAME={name}</span>
                </div>
                <div class="env-row">
                    <span class="key">Runtime</span>
                    <span class="value">Flask on port 8080</span>
                </div>
                <p class="note">
                    The page is served from a container running in Kubernetes.
                    The greeting value is provided through ConfigMap and passed
                    into the application as an environment variable.
                </p>
                <footer>Deployment + ConfigMap + Service + Ingress</footer>
            </main>
        </div>
    </body>
    </html>
    '''

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
